// JavaScript File
/* global $ */
$(".menu").click(function() {
    $(".slide").slideToggle();
});

$(".slide").hide();

$(".fg").hide();

$(".fb").click(function() {
    $(".fg").show();
});

$(".fb").click(function() {
    $(".fb").hide();
});

$(".fg").click(function() {
    $(".fb").show();
});

$(".fg").click(function() {
    $(".fg").hide();
});
