// JavaScript File
function check1() {
  var question1 = document.quiz1.question1.value;
  var question2 = document.quiz1.question2.value;
  var question3 = document.quiz1.question3.value;
  var question4 = document.quiz1.question4.value;
  var question5 = document.quiz1.question5.value;
  var score = 0;

  if (question1 == "Jennifer Aniston in the 90s") { score += 1; }
  if (question1 == "Oprah Winfrey") { score += 2; }
  if (question1 == "Mary Kate Olsen") { score += 3; }
  if (question1 == "Emma Watson") { score += 4; }
  if (question1 == "Emma Chamberlin") { score += 5; }

  if (question2 == "Cute overalls") { score += 1; }
  if (question2 == "Plain T-shirt") { score += 2; }
  if (question2 == "Converse ") { score += 3; }
  if (question2 == "Blouse") { score += 4; }
  if (question2 == "Mom jeans") { score += 5; }

  if (question3 == "Thrift shops") { score += 1; }
  if (question3 == "They’re all hand-me downs") { score += 2; }
  if (question3 == "Random stores") { score += 3; }
  if (question3 == "J.Crew and Banana Republic") { score += 4; }
  if (question3 == "Forever 21 and Brandy Melville") { score += 5; }

  if (question4 == "Taking pictures with your polaroid") { score += 1; }
  if (question4 == "At home watching TV shows") { score += 2; }
  if (question4 == "Skating at the skate park") { score += 3; }
  if (question4 == "Outside running errands") { score += 4; }
  if (question4 == "Shopping") { score += 5; }

  if (question5 == "A woman wearing a blazer and sleek dress on the catwalk") { score += 1; }
  if (question5 == "A girl showing her outfit on her last day of high school") { score += 2; }
  if (question5 == "A celebrity rocking a band tee on the street") { score += 3; }
  if (question5 == "A man wearing a clean suit during a photoshoot") { score += 4; }
  if (question5 == "A picture of a group of friends going to see a movie") { score += 5; }

  var messages = ["You are an old soul. Some inspirational people with your style are TLC and the Spice Girls.",
    "You are laid back. Your main priority when looking for an outfit is comfort.",
    "You care a lot about the earth. You like wearing flannels and flowy clothing.",
    "You try and show the best version of yourself. You are all about business and want people to take you seriously.",
    "You know what’s popping in the media. You are constantly buying new clothes to upgrade your wardrobe."
  ]

  var range;
  if (score <= 5) { range = 0; }
  if (score > 5 && score <= 10) { range = 1; }
  if (score > 10 && score <= 15) { range = 2; }
  if (score > 15 && score <= 20) { range = 3; }
  if (score > 20 && score <= 25) { range = 4; }

  document.getElementById("after_submit").style.visibility = "visible";
  document.getElementById("message").innerHTML = messages[range];
}
