// JavaScript File
function check2() {
  var question1a = document.quiz2.question1a.value;
  var question2a = document.quiz2.question2a.value;
  var question3a = document.quiz2.question3a.value;
  var question4a = document.quiz2.question4a.value;
  var question5a = document.quiz2.question5a.value;
  var question6a = document.quiz2.question6a.value;
  var question7a = document.quiz2.question7a.value;
  var score2 = 0;

  if (question1a == "Strawberry") { score2 += 1; }
  if (question1a == "Vanilla") { score2 += 2; }
  if (question1a == "Chocolate ") { score2 += 3; }
  if (question1a == "Mint chocolate chip") { score2 += 4; }
  if (question1a == "Cake batter") { score2 += 5; }

  if (question2a == "Gummy bears") { score2 += 1; }
  if (question2a == "M&Ms") { score2 += 2; }
  if (question2a == "Crushed oreos") { score2 += 3; }
  if (question2a == "Coconut") { score2 += 4; }
  if (question2a == "Rainbow sprinkles") { score2 += 5; }

  if (question3a == "Peanuts") { score2 += 1; }
  if (question3a == "Chocolate sprinkles") { score2 += 2; }
  if (question3a == "Mochi") { score2 += 3; }
  if (question3a == "Fruity pebbles") { score2 += 4; }
  if (question3a == "Mango popping boba") { score2 += 5; }

  if (question4a == "Caramel") { score2 += 1; }
  if (question4a == "Hot fudge") { score2 += 2; }
  if (question4a == "Whipped cream") { score2 += 3; }
  if (question4a == "Honey") { score2 += 4; }
  if (question4a == "Chocolate sauce") { score2 += 5; }

  if (question5a == "Two") { score2 += 1; }
  if (question5a == "Three") { score2 += 2; }
  if (question5a == "As many as possible") { score2 += 3; }
  if (question5a == "One") { score2 += 4; }
  if (question5a == "Four") { score2 += 5; }

  if (question6a == "Regular cone") { score2 += 1; }
  if (question6a == "Sugar cone") { score2 += 2; }
  if (question6a == "Plastic cup") { score2 += 3; }
  if (question6a == "Bowl") { score2 += 4; }
  if (question6a == "Waffle cone") { score2 += 5; }

  if (question7a == "Yes") { score2 += 1; }
  if (question7a == "Only if they ask") { score2 += 2; }
  if (question7a == "NO") { score2 += 3; }
  if (question7a == "We'll each get our own") { score2 += 4; }
  if (question7a == "Maybe a little") { score2 += 5; }

  var messages2 = ["You are an old soul. Some inspirational people with your style are TLC and the Spice Girls.",
    "You are laid back. Your main priority when looking for an outfit is comfort.",
    "You care a lot about the earth. You like wearing flannels and flowy clothing.",
    "You try and show the best version of yourself. You are all about business and want people to take you seriously.",
    "You know what’s popping in the media. You are constantly buying new clothes to upgrade your wardrobe."
  ]
  var range2;
  if (score2 <= 10) { range2 = 0; }
  if (score2 > 10 && score2 <= 20) { range2 = 1; }
  if (score2 > 20 && score2 <= 30) { range2 = 2; }
  if (score2 > 30 && score2 <= 40) { range2 = 3; }
  if (score2 > 40 && score2 <= 49) { range2 = 4; }


  document.getElementById("after_submit2").style.visibility = "visible";
  document.getElementById("message2").innerHTML = messages2[range2];
}
