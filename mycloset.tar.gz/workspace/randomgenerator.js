// JavaScript File

// 90S OUTFITS
function myFunction1() {
  var shirt = ["image (901).png", "image (902).png", "image (903).png"];
  var pants = ["image (904).png", "image (905).png", "image (906).png"];
  var shoes = ["image (907).png", "image (908).png", "image (909).png"];
  var randomList = [];

  var ranShirt = shirt[Math.floor(Math.random() * shirt.length)];
  var ranPants = pants[Math.floor(Math.random() * pants.length)];
  var ranShoes = shoes[Math.floor(Math.random() * shoes.length)];

  randomList.push(ranShirt);
  randomList.push(ranPants);
  randomList.push(ranShoes);

  for (i = 0; i < randomList.length; i++) {
    var img = document.createElement("IMG");
    img.src = randomList[i];
    img.className = "image";
    var parent = document.getElementById("x");
    parent.appendChild(img);
  }
}

// CASUAL OUTFITS
function myFunction2() {
  var shirt = ["image (c4).png", "image (c5).png", "image (c6).png"];
  var pants = ["image (c1).png", "image (c2).png", "image (c3).png"];
  var shoes = ["image (c7).png", "image (c8).png", "image (c9).png"];
  var randomList = [];

  var ranShirt = shirt[Math.floor(Math.random() * shirt.length)];
  var ranPants = pants[Math.floor(Math.random() * pants.length)];
  var ranShoes = shoes[Math.floor(Math.random() * shoes.length)];

  randomList.push(ranShirt);
  randomList.push(ranPants);
  randomList.push(ranShoes);

  for (i = 0; i < randomList.length; i++) {
    var img = document.createElement("IMG");
    img.src = randomList[i];
    img.className = "image";
    var parent = document.getElementById("x");
    parent.appendChild(img);
  }
}

// HIPSTER OUTFITS
function myFunction3() {
  var shirt = ["image (h1).png", "image (h2).png", "image (h3).png"];
  var pants = ["image (h4).png", "image (h5).png", "image (h6).png"];
  var shoes = ["image (h7).png", "image (h8).png", "image (h9).png"];
  var randomList = [];

  var ranShirt = shirt[Math.floor(Math.random() * shirt.length)];
  var ranPants = pants[Math.floor(Math.random() * pants.length)];
  var ranShoes = shoes[Math.floor(Math.random() * shoes.length)];

  randomList.push(ranShirt);
  randomList.push(ranPants);
  randomList.push(ranShoes);

  for (i = 0; i < randomList.length; i++) {
    var img = document.createElement("IMG");
    img.src = randomList[i];
    img.className = "image";
    var parent = document.getElementById("x");
    parent.appendChild(img);
  }
}

// PROFESSIONAL OUTFITS
function myFunction4() {
  var shirt = ["image (p4).png", "image (p5).png", "image (p6).png"];
  var pants = ["image (p1).png", "image (p2).png", "image (p3).png"];
  var shoes = ["image (p7).png", "image (p8).png", "image (p9).png"];
  var randomList = [];

  var ranShirt = shirt[Math.floor(Math.random() * shirt.length)];
  var ranPants = pants[Math.floor(Math.random() * pants.length)];
  var ranShoes = shoes[Math.floor(Math.random() * shoes.length)];

  randomList.push(ranShirt);
  randomList.push(ranPants);
  randomList.push(ranShoes);

  for (i = 0; i < randomList.length; i++) {
    var img = document.createElement("IMG");
    img.src = randomList[i];
    img.className = "image";
    var parent = document.getElementById("x");
    parent.appendChild(img);
  }
}

// TRENDY OUTFITS
function myFunction5() {
  var shirt = ["image (t1).png", "image (t2).png", "image (t3).png"];
  var pants = ["image (t4).png", "image (t5).png", "image (t6).png"];
  var shoes = ["image (t7).png", "image (t8).png", "image (t9).png"];
  var randomList = [];

  var ranShirt = shirt[Math.floor(Math.random() * shirt.length)];
  var ranPants = pants[Math.floor(Math.random() * pants.length)];
  var ranShoes = shoes[Math.floor(Math.random() * shoes.length)];

  randomList.push(ranShirt);
  randomList.push(ranPants);
  randomList.push(ranShoes);

  // for ("image"){
  // remove;
  // }

  for (i = 0; i < randomList.length; i++) {
    var img = document.createElement("IMG");
    img.src = randomList[i];
    img.className = "image";
    var parent = document.getElementById("x");
    parent.appendChild(img);
  }
}
